from typing import Tuple

def ias_lookup(tag_id: str) -> Tuple[bool, str]:

    return False, "Actual connection to IAS yet to establish"